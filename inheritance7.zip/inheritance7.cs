﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inheritance7
{
    public partial class Form1 : Form
    {
        class addshoe
        {
            protected string type;
            protected string size;

            public addshoe(string fn, string ln)
            {
                this.type = type;
                this.size = size;
                MessageBox.Show("inside add shoe constructor " + type + " " + size);
            }
            public void display()
            {
                MessageBox.Show("inside add shoe display " + type + " " + size);
            }
            public string gettype()
            {
                return type;
            }
            public string getsize()
            {
                return size;
            }

        }
        class color : addshoe
        {
            private double boot;

            public color(string type, string size, double color) : base(type, size)
            {
                color = color;
            }
            public void displayFT()
            {
                MessageBox.Show(" in color display " + boot.ToString());
                MessageBox.Show(" in boot display " + type + " " + size);
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            addshoe e1 = new addshoe(textBox1.Text, textBox2.Text);
            e1.display();
        }
    }
}
