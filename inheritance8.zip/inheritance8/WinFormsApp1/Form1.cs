﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        class addshoe
        {
            protected string color;
            protected double size;
            
            public addshoe(string Color, double Size)
            {
                this.color = Color;
                this.size = Size;
                MessageBox.Show("inside type constructor " + color + " " + size);
            }
            public void display()
            {
                MessageBox.Show("inside size display " + color + " " + size);
            }
            public string getcolor()
            {
                return color;
            }
            public double getsize()
            {
                return size;
            }

        }
        class boot : addshoe
        {
            private string type ;

            
            public boot(string type, string Color, double Size) : base (Color,Size)
            {
                this.type = type;
            }
            public void displayboot()
            {
                base.display();
                MessageBox.Show("in boot display " + type.ToString());
               
            }
        }
        
        class addsandal : addshoe
        {
            private string type;


            public addsandal(string thong, double buckle, string type) : base(thong, buckle)
            {
                this.type = type;
            }
            public void displaytype()
            {
                base.display();
                MessageBox.Show("in sandal display " + type.ToString());

            }
        }
        public Form1()

        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            addshoe shoe1 = new addshoe(textBox1.Text, double.Parse(textBox2.Text));
            shoe1.display();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            boot boot1 = new boot(textBox3.Text, textBox1.Text, double.Parse(textBox2.Text));
                //:base(textBox1.Text, double.Parse(textBox2.Text));
            boot1.displayboot();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addshoe sandal1 = new addshoe(textBox3.Text, double.Parse(textBox4.Text));
            sandal1.display();
        }
    }
}
