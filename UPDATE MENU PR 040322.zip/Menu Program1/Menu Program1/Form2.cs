﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Menu_Program1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //CHANGE IN TEXT 04/03/22
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            this.Hide();
            frm.Show();
            //BUTTON GOES TO MENU 3/31/22
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //CHANGE IN TEXT 04/03/22
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //CHANGE IN TEXT 04/03/22
        }
    }
}
